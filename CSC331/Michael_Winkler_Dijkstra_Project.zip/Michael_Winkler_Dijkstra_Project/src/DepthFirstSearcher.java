import java.util.HashMap;
import java.util.LinkedList;
import java.util.Queue;


public class DepthFirstSearcher {
	
	/*
	 * Depth-first search exploration
	 */
	public void explore(Graph<Vertex> g, Vertex v) {
	
	}

	/*
	 * Depth-First search
	 */
	public void depthFirstSearch(Graph<Vertex> g){
	
	}
	
	
	
	public void printDFSDataStructures(){
		
	}
}
