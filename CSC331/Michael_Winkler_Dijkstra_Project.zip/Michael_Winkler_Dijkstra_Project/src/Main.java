//Michael Winkler
//CSC331, 4/27/16
import java.util.HashMap;

public class Main {
	public static void main(String [] args) {
		Dijkstra d = new Dijkstra();
		d.go();
	}
}
