SELECT 
	firstname,
    lastname
FROM
    healthcare.provider
WHERE type_code = 'P'
;