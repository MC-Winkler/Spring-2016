SELECT 
    item
FROM
    healthcare.medicalconcept
WHERE
    item LIKE 'temp %'
;