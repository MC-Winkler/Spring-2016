SELECT
       classes_num, 
       seat_num, 
       student_id_fk
FROM   tngmgr.classregistration
LIMIT 100 
;


