SELECT 
    course_name AS "Course"
FROM
    tngmgr.courses
LIMIT 5
;