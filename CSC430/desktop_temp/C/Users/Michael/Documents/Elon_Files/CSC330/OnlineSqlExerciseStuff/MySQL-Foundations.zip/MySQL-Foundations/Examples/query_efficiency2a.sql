EXPLAIN EXTENDED SELECT 
 symbol,
 tradedate
FROM financial.securities
WHERE symbol = 'JNJ'
;